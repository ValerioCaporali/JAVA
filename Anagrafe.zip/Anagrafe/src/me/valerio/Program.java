package me.valerio;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Program {

    static List<Person> anagrafe = new ArrayList<>();

    public static void add(String name, String surname, int age) {

        Person p = new Person(name, surname, age);
        anagrafe.add(p);

    }
}