package me.valerio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Anagrafe {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Anagrafe");
        frame.setSize(1366, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        JTextField nameField = new JTextField();
        JTextField surnameField = new JTextField();
        JTextField ageField = new JTextField();
        JLabel name = new JLabel("Name");
        JLabel surname = new JLabel("Surname");
        JLabel age = new JLabel("Age");
        JButton button = new JButton("Save");


        //Per mettere un elemento sotto l'altro
        panel.setBorder(BorderFactory.createTitledBorder("New Person"));
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        layout.setHorizontalGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(name)
                        .addComponent(surname)
                        .addComponent(age))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(nameField)
                        .addComponent(surnameField)
                        .addComponent(ageField)
                .addComponent(button))
        );

        layout.setVerticalGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(name)
                        .addComponent(nameField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(surname)
                        .addComponent(surnameField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(age)
                        .addComponent(ageField))
                .addComponent(button)
        );

        frame.setVisible(true);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    Program.add(nameField.getText(), surnameField.getText(), Integer.valueOf(ageField.getText()));
                } catch (NumberFormatException e){
                    JOptionPane.showMessageDialog(null, "Age is not a number");
                }
            }
        });

    }
}
